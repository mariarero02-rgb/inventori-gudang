# Inventori Gudang

Aplikasi Android (Kotlin + Jetpack Compose) untuk inventory gudang.

## Tahap 1 (ini)
Kerangka project + 5 menu: Produk, Masuk, Keluar, Gudang, Transfer (layar masih kosong).

## Cara pakai
- **Android Studio**: File > Open > pilih folder ini, tunggu Gradle sync, lalu Run.
- **GitHub**: upload isi folder ke repo, lalu Actions > "Build dan Rilis APK" > Run workflow. APK muncul di bagian Releases.
