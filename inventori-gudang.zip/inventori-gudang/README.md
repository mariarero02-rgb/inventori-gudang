# Inventori Gudang

Aplikasi Android (Kotlin + Jetpack Compose) untuk inventory gudang.

## Tahap 2 (ini)
Menu **Produk** sudah berfungsi: database di HP (Room), tambah, ubah, hapus, dan cari produk (kode, nama, satuan, harga). Kode produk tidak boleh kembar.
Menu lain (Masuk, Keluar, Gudang, Transfer) masih layar kosong.

## Cara pakai
- **Android Studio**: File > Open > pilih folder ini, tunggu Gradle sync, lalu Run.
- **GitHub**: upload isi folder ke repo, lalu Actions > "Build dan Rilis APK" > Run workflow. APK muncul di bagian Releases.
