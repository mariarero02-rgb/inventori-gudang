package com.example.inventorygudang.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF1E5A8E),
    secondary = Color(0xFF3F7F6B)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF8DC1F0),
    secondary = Color(0xFF8CCDB6)
)

@Composable
fun InventoriTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content
    )
}
