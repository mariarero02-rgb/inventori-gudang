package com.example.inventorygudang.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProdukDao {
    @Query(
        "SELECT * FROM produk WHERE kode LIKE '%' || :cari || '%' " +
            "OR nama LIKE '%' || :cari || '%' ORDER BY nama COLLATE NOCASE"
    )
    fun cari(cari: String): Flow<List<Produk>>

    @Query("SELECT COUNT(*) FROM produk WHERE kode = :kode AND id != :id")
    suspend fun hitungKode(kode: String, id: Long): Int

    @Insert
    suspend fun tambah(produk: Produk): Long

    @Update
    suspend fun ubah(produk: Produk)

    @Delete
    suspend fun hapus(produk: Produk)
}
