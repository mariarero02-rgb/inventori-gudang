package com.example.inventorygudang.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

/** Satu item menu utama aplikasi. */
enum class Menu(
    val route: String,
    val judul: String,
    val ikon: ImageVector,
    val keterangan: String
) {
    PRODUK("produk", "Produk", Icons.Filled.Inventory2, "Data produk: kode, nama, satuan, harga."),
    MASUK("masuk", "Masuk", Icons.Filled.Download, "Barang masuk ke gudang."),
    KELUAR("keluar", "Keluar", Icons.Filled.Upload, "Barang keluar dari gudang."),
    GUDANG("gudang", "Gudang", Icons.Filled.Store, "Gudang 1 (utama), Gudang 2 (kanvas), dan seterusnya."),
    TRANSFER("transfer", "Transfer", Icons.Filled.SwapHoriz, "Pindah stok antar gudang.")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNav() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val rute = backStack?.destination?.route

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(Menu.entries.firstOrNull { it.route == rute }?.judul ?: "Inventori Gudang") }
            )
        },
        bottomBar = {
            NavigationBar {
                Menu.entries.forEach { menu ->
                    NavigationBarItem(
                        selected = rute == menu.route,
                        onClick = {
                            nav.navigate(menu.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(menu.ikon, contentDescription = menu.judul) },
                        label = { Text(menu.judul, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Menu.PRODUK.route,
            modifier = Modifier.padding(padding)
        ) {
            Menu.entries.forEach { menu ->
                composable(menu.route) { LayarKosong(menu) }
            }
        }
    }
}

/** Layar sementara; akan diganti layar sungguhan di tahap berikutnya. */
@Composable
fun LayarKosong(menu: Menu) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(menu.ikon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(menu.judul, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))
            Text(menu.keterangan, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
