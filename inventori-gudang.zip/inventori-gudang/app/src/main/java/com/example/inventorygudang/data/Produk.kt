package com.example.inventorygudang.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "produk", indices = [Index(value = ["kode"], unique = true)])
data class Produk(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kode: String,
    val nama: String,
    val satuan: String,
    val harga: Long
)
