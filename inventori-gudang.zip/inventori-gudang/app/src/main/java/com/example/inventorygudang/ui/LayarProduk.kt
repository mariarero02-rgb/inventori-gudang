package com.example.inventorygudang.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.inventorygudang.data.Produk
import com.example.inventorygudang.data.ProdukViewModel
import java.text.NumberFormat
import java.util.Locale

private fun rupiah(angka: Long): String =
    "Rp " + NumberFormat.getIntegerInstance(Locale("id", "ID")).format(angka)

@Composable
fun LayarProduk(vm: ProdukViewModel = viewModel()) {
    val daftar by vm.daftar.collectAsState()
    var cari by remember { mutableStateOf("") }
    var form by remember { mutableStateOf<Produk?>(null) }
    var hapusProduk by remember { mutableStateOf<Produk?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            OutlinedTextField(
                value = cari,
                onValueChange = { cari = it; vm.setCari(it) },
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp),
                placeholder = { Text("Cari kode atau nama") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true
            )
            Text(
                "${daftar.size} produk",
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            if (daftar.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (cari.isBlank()) "Belum ada produk. Ketuk tombol + untuk menambah."
                        else "Produk tidak ditemukan."
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(daftar, key = { it.id }) { p ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.nama, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${p.kode} • ${p.satuan}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        rupiah(p.harga),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { form = p }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Ubah")
                                }
                                IconButton(onClick = { hapusProduk = p }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Hapus")
                                }
                            }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { form = Produk(kode = "", nama = "", satuan = "pcs", harga = 0) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Tambah produk")
        }
    }

    form?.let { awal ->
        FormProduk(
            awal = awal,
            onBatal = { form = null },
            onSimpan = { produk, hasil -> vm.simpan(produk) { galat -> hasil(galat); if (galat == null) form = null } }
        )
    }

    hapusProduk?.let { p ->
        AlertDialog(
            onDismissRequest = { hapusProduk = null },
            title = { Text("Hapus produk?") },
            text = { Text("${p.nama} (${p.kode}) akan dihapus.") },
            confirmButton = {
                TextButton(onClick = { vm.hapus(p); hapusProduk = null }) { Text("Hapus") }
            },
            dismissButton = {
                TextButton(onClick = { hapusProduk = null }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun FormProduk(
    awal: Produk,
    onBatal: () -> Unit,
    onSimpan: (Produk, (String?) -> Unit) -> Unit
) {
    var kode by remember(awal) { mutableStateOf(awal.kode) }
    var nama by remember(awal) { mutableStateOf(awal.nama) }
    var satuan by remember(awal) { mutableStateOf(awal.satuan) }
    var harga by remember(awal) { mutableStateOf(if (awal.harga == 0L) "" else awal.harga.toString()) }
    var galat by remember(awal) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onBatal,
        title = { Text(if (awal.id == 0L) "Tambah produk" else "Ubah produk") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(kode, { kode = it }, label = { Text("Kode") }, singleLine = true)
                OutlinedTextField(nama, { nama = it }, label = { Text("Nama") }, singleLine = true)
                OutlinedTextField(satuan, { satuan = it }, label = { Text("Satuan (pcs, dus, kg)") }, singleLine = true)
                OutlinedTextField(
                    harga,
                    { teks -> harga = teks.filter { it.isDigit() } },
                    label = { Text("Harga (Rp)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                galat?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    kode.isBlank() -> galat = "Kode wajib diisi"
                    nama.isBlank() -> galat = "Nama wajib diisi"
                    satuan.isBlank() -> galat = "Satuan wajib diisi"
                    else -> onSimpan(
                        awal.copy(
                            kode = kode.trim(),
                            nama = nama.trim(),
                            satuan = satuan.trim(),
                            harga = harga.toLongOrNull() ?: 0L
                        )
                    ) { hasil -> galat = hasil }
                }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onBatal) { Text("Batal") } }
    )
}
