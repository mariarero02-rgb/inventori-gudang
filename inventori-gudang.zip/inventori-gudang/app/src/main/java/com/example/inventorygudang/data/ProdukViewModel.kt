package com.example.inventorygudang.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProdukViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).produkDao()
    private val kataCari = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val daftar: StateFlow<List<Produk>> = kataCari
        .flatMapLatest { dao.cari(it.trim()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setCari(teks: String) {
        kataCari.value = teks
    }

    /** Simpan produk baru (id = 0) atau ubah yang ada. onSelesai(null) bila berhasil, atau pesan galat. */
    fun simpan(produk: Produk, onSelesai: (String?) -> Unit) {
        viewModelScope.launch {
            if (dao.hitungKode(produk.kode, produk.id) > 0) {
                onSelesai("Kode sudah dipakai produk lain")
            } else {
                if (produk.id == 0L) dao.tambah(produk) else dao.ubah(produk)
                onSelesai(null)
            }
        }
    }

    fun hapus(produk: Produk) {
        viewModelScope.launch { dao.hapus(produk) }
    }
}
